<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="vscode插件demo" LOCALIZED_STYLE_REF="AutomaticLayout.level.root" FOLDED="false" ID="ID_1090958577" CREATED="1409300609620" MODIFIED="1715611652655"><hook NAME="MapStyle" background="#2e3440">
    <properties show_icon_for_attributes="true" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff" show_note_icons="true" fit_to_viewport="false" associatedTemplateLocation="template:/dark_nord_template.mm"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ID="ID_671184412" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#484747" BACKGROUND_COLOR="#eceff4" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="8 pt" SHAPE_VERTICAL_MARGIN="5 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="1.9 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#f0f0f0" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#88c0d0" WIDTH="2" TRANSPARENCY="255" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_671184412" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="11" BOLD="false" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#81a1c1" WIDTH="3" DASH="SOLID"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/auto"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/auto"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" BORDER_WIDTH="1.9 px">
<edge STYLE="bezier" COLOR="#81a1c1" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ebcb8b">
<icon BUILTIN="clock2"/>
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#484747">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" COLOR="#e5e9f0" BACKGROUND_COLOR="#5e81ac" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#5e81ac"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.important" ID="ID_779275544" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#bf616a">
<icon BUILTIN="yes"/>
<arrowlink COLOR="#bf616a" TRANSPARENCY="255" DESTINATION="ID_779275544"/>
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.flower" COLOR="#ffffff" BACKGROUND_COLOR="#255aba" STYLE="oval" TEXT_ALIGN="CENTER" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="22 pt" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#f9d71c" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="CLOSE_DOTS" MAX_WIDTH="6 cm" MIN_WIDTH="3 cm"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#ffffff" BACKGROUND_COLOR="#484747" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="10 pt" SHAPE_VERTICAL_MARGIN="10 pt">
<font NAME="Ubuntu" SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#eceff4" BACKGROUND_COLOR="#d08770" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="8 pt" SHAPE_VERTICAL_MARGIN="5 pt">
<font NAME="Ubuntu" SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#3b4252" BACKGROUND_COLOR="#ebcb8b">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#2e3440" BACKGROUND_COLOR="#a3be8c">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#2e3440" BACKGROUND_COLOR="#b48ead">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" BACKGROUND_COLOR="#81a1c1">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" BACKGROUND_COLOR="#88c0d0">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" BACKGROUND_COLOR="#8fbcbb">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" BACKGROUND_COLOR="#d8dee9">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" BACKGROUND_COLOR="#e5e9f0">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" BACKGROUND_COLOR="#eceff4">
<font SIZE="9"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<font BOLD="true"/>
<node TEXT="背景" POSITION="bottom_or_right" ID="ID_503163449" CREATED="1715611652979" MODIFIED="1715611660132">
<node TEXT="常用的插件类型" FOLDED="true" ID="ID_1176097685" CREATED="1715611671907" MODIFIED="1715612111067">
<node TEXT="拓展命令插件" ID="ID_448930882" CREATED="1715612087519" MODIFIED="1715612140698">
<node TEXT="eslint" ID="ID_378600902" CREATED="1715612495477" MODIFIED="1715612499039"/>
</node>
<node TEXT="色彩主题插件" ID="ID_1243353143" CREATED="1715612155693" MODIFIED="1715612168553"/>
<node TEXT="应用型插件" ID="ID_603472614" CREATED="1715612168740" MODIFIED="1715612210840">
<node TEXT="原生UI为主的插件" ID="ID_237259608" CREATED="1715612210965" MODIFIED="1715613121535"/>
<node TEXT="WEB实例型插件" ID="ID_1985632084" CREATED="1715612237143" MODIFIED="1715613128633"/>
</node>
<node TEXT="文档插件" ID="ID_378641881" CREATED="1715612259112" MODIFIED="1715612327989"/>
<node TEXT="调试器插件" ID="ID_701442862" CREATED="1715612328442" MODIFIED="1715612354317">
<node TEXT="" ID="ID_790315462" CREATED="1715612502853" MODIFIED="1715612502853"/>
</node>
<node TEXT="等等" ID="ID_1245838843" CREATED="1715612394641" MODIFIED="1715612396754"/>
<node TEXT="png-240513-230058506-5598673814342672672.png" POSITION="bottom_or_right" ID="ID_322907287" CREATED="1715612461946" MODIFIED="1715612461946">
<hook URI="vscode插件demo_files/png-240513-230058506-5598673814342672672.png" SIZE="1.0" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="demo" POSITION="bottom_or_right" ID="ID_252610166" CREATED="1715612744227" MODIFIED="1715612748580">
<node TEXT="准备" ID="ID_1082895183" CREATED="1715612748580" MODIFIED="1715612755822">
<node TEXT="npm的yo插件能快速搭建初始项目" ID="ID_1325370172" CREATED="1715612831505" MODIFIED="1715612854793">
<node TEXT="目录结构" ID="ID_399595085" CREATED="1715612878791" MODIFIED="1715612882591"/>
</node>
<node TEXT="ts/js" ID="ID_1422275924" CREATED="1715612870939" MODIFIED="1715612890727"/>
<node TEXT="客户端能力" ID="ID_1971707580" CREATED="1715612990763" MODIFIED="1715612996678">
<node TEXT="SSH连接远端服务器" ID="ID_1972052267" CREATED="1715613057122" MODIFIED="1715613068507"/>
<node TEXT="文件处理接口" ID="ID_1729056899" CREATED="1715613069101" MODIFIED="1715613078358"/>
<node TEXT="数据库能力" ID="ID_1955264371" CREATED="1715613080031" MODIFIED="1715613090245"/>
</node>
</node>
<node TEXT="DEMO" ID="ID_1153172302" CREATED="1715612756324" MODIFIED="1715612758940">
<node TEXT="测试框架搭建" ID="ID_1709814160" CREATED="1715613158309" MODIFIED="1715613168692"/>
<node TEXT="打包、发布框架搭建" ID="ID_1762305479" CREATED="1715613182817" MODIFIED="1715613268320"/>
</node>
<node TEXT="" ID="ID_1962473918" CREATED="1715612759487" MODIFIED="1715612759487"/>
</node>
<node TEXT="参考资料" POSITION="bottom_or_right" ID="ID_1774620148" CREATED="1715611679889" MODIFIED="1715612722979">
<node TEXT="https://rackar.github.io/vscode-ext-doccn/extension-authoring/webview-api.html#%E5%8A%A0%E8%BD%BD%E6%9C%AC%E5%9C%B0%E5%86%85%E5%AE%B9" POSITION="bottom_or_right" ID="ID_604526644" CREATED="1715612704897" MODIFIED="1715612704897" LINK="https://rackar.github.io/vscode-ext-doccn/extension-authoring/webview-api.html#%E5%8A%A0%E8%BD%BD%E6%9C%AC%E5%9C%B0%E5%86%85%E5%AE%B9"/>
</node>
</node>
</map>
